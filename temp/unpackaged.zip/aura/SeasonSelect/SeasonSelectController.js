({
	doInit : function(component, event, helper) {
        helper.onInit(component);
	},
    doChange : function(component, event, helper) {
        helper.onChange(component);
    }
})