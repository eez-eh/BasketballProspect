({
	doInit : function(component, event, helper) {
        helper.onInit(component);
    },
	handleSeasonSelect : function(component, event, helper) {
        helper.seasonSelect(component, event);
	}
})